# 🌙 THT Instagram SPAM Atıcı

## 🔥 Nedir?
Belirlediğiniz şikayet nedeni ile bir hesabp için instagrama şikayet isteği atmanızı sağlayan bir programdır.

**Programın videolarını çektiği için Akif kardeşime teşekkür ediyorum!**

![Screenshot](https://github.com/tarik0/instaspamv2/blob/master/ss.png)

 ## 💻 Kurulum
 
 [![Windows Kurulum](https://img.youtube.com/vi/XU6nJ__anaY/0.jpg)](https://www.youtube.com/watch?v=XU6nJ__anaY)
 
 
 ## 🤔 Sıkça Sorulan Sorular

### # Kullanıcıların ID'sini nereden bulabiliriz?
[Buradaki](https://codeofaninja.com/tools/find-instagram-user-id) adresinden bulabilirsiniz.
### # Spam atmama rağmen hesap kapanmadı?

Hesapların **%100** kapanma garantisi **yoktur.**

### # Kullanıcılar doğru olduğu halde giriş yapılamıyor?

Hesaplarınız %90 doğrulamaya düşüyordur veya proxylerinizde sıkıntı vardır.

### # Kullanıcı dosyasını nasıl doldurmalıyım?
Her satıra 1 kullanıcı olacak şekilde ve **kullanici_adi sifre** formatında yazmalısınız. **(Örn. necmi_selim 123sifre12)**

### # Proxy dosyasını nasıl doldurmalıyım?
Her satıra 1 proxy olacak şekilde ve **ip: port** formatında yazmalısınız. **(Örn. 1.1.1.1:8080)**

### # Sürekli proxyler çalışmıyor hatası alıyorum?
Programı proxy ile kullanmak zorunda değilsiniz. Instagram'ın bu olayını ben de tamamen çözebilmiş değilim.

### # Proxy normalde çalıştığı halde programda çalışmıyor!
Proxyleriniz **HTTPS** destekli olmalıdır aksi halde çalışmaz.

## 📞 İletişim

Forum dışındaki iletişim bilgilerim;

**Telegram:** @Hichigo06 
**Instagram:** @hichigo.exe

**akovskiniz Instagram:** @akifdora0
**akovskiniz YouTube:**  [![Akif Dora](https://www.youtube.com/channel/UCxaifS9Pam5QDp1NE2SPXqA)]

##  ⚖️ Lisans

Bu program **GPLv3** lisansı altındadır. Lütfen programı değiştirip kullanmadan önce alttaki bağlantıları okuyunuz!

https://tr.wikipedia.org/wiki/GNU_Genel_Kamu_Lisans%C4%B1
https://www.gnu.org/licenses/quick-guide-gplv3.html

**Program ile yapacağınız herhangi bir işlemden ben sorumlu değilim. Bu riski göz önüne alarak kullanın.**
